<html>
<meta charset="UTF-8">

<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/bootstrap-table.min.css">

    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>

    <script src="../js/bootstrap-table.min.js"></script>
    <script src="../js/bootstrap-table-fr-FR.min.js"></script>
    <script src="../js/bootstrap-table-export.min.js"></script>

  
<title>Détail du sujet</title>
</head>
<style>
.bootstrap-table .fixed-table-container .fixed-table-body {
		height: unset !important;
	}
</style>

<body>
<nav class="navbar navbar-expand-sm "  style = "height: 5%; background-color: green;">
    <div class="collapse navbar-collapse" id="navbarNavDropdown" >
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class ="nav-link" href="accueil.php" style = "color:white;"><strong>Accueil</strong></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inscription.php" style = "color:white;"><strong>Inscription</strong></a>
            </li>
        </ul>
    </div>
</nav>

<br><br>
<?php
if (!isset($_GET['id_sujet_a_lire'])) {
	echo 'Sujet non défini.';
}
else {
?>
	<div class = "container" style = "width:75%;">
	<table style  = "text-align:center;" id="tbl-sujet" class ="table table-striped table-hover"
	data-toggle="table" 
        data-pagination="true" 
		data-page-size="15" 
        data-page-list="[5,10,15,20,50,100,200,500,All]" 
        data-page-size="10" 
        data-page-list="[10]" 
        data-show-refresh="true"
        data-search="true" 
        data-show-export="true" 
        data-export-data-type="all" >
            <thead style = "text-align: center;">
				<tr>
					<th>Titre</th>
					<th>Sujet</th>
				<tr>
			</thead>

<?php
// on inclut ce fichier qui permet la connexion à notre base de données
include_once("bd.php");
$id = $_GET['id_sujet_a_lire'];
$commentaire = $bd->prepare('SELECT posts.content,title FROM posts where posts.id = :id');
$commentaire->execute(array('id'=>$id));
$tab = $commentaire->fetchALL();

$comm = $bd->prepare('SELECT comments.content,username FROM comments inner join posts ON posts.id = comments.idPost inner join users ON users.id=comments.id where idPost = :id');
$comm->execute(array(':id'=>$id));
$tab_c = $comm->fetchALL();
foreach($tab as $key => $data) {
	
		// on affiche les résultats
		echo '<tbody>';
		echo '<tr>';
		echo '<td>';
		echo htmlentities(trim($data['title']));
		echo '</td><td>';
		echo nl2br(htmlentities(trim($data['content'])));
		echo '</td></tr>';
	}
?>
	</tbody>
	</table>


	<br><br>
<table  style  = "text-align:center;" id="tbl-sujet" class ="table table-striped table-hover"
	data-toggle="table" 
        data-pagination="true" 
		data-page-size="15" 
        data-page-list="[5,10,15,20,50,100,200,500,All]" 
        data-page-size="10" 
        data-page-list="[10]" 
        data-show-refresh="true"
        data-search="true" 
        data-show-export="true" 
        data-export-data-type="all" >
		<thead style = "text-align: center;">
		<tr>
			<th>Réponse</th>
			<th>Utilisateur</th>
		<tr>
		</thead>
		<tbody>
</tr>
	<?php 
		foreach($tab_c as $key => $data) {
	
		// on affiche les résultats
		echo '<tr>';
		echo '<td>';
		echo nl2br(htmlentities(trim($data['content'])));
		echo '</td><td>';
		echo nl2br(htmlentities(trim($data['username'])));
		echo '</td></tr>';
	}
	?>
	</tbody>
	</table>
	<br /><br>
	<center>
	<a href="reponse.php?numero_du_sujet=<?php echo $_GET['id_sujet_a_lire']; ?>"
	<button class = 'btn btn-primary'>Répondre</button>
	</a>
	</center>
	<?php
	}

?>
</div>
<br /><br />

</body>
</html>