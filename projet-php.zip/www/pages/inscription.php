<head>
  <meta charset="UTF-8">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/bootstrap-table.min.css">

    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>

    <script src="../js/bootstrap-table.min.js"></script>
    <script src="../js/bootstrap-table-fr-FR.min.js"></script>
    <script src="../js/bootstrap-table-export.min.js"></script>
</head>


<body>

<nav class="navbar navbar-expand-sm "  style = "height: 5%; background-color: green;">
    <div class="collapse navbar-collapse" id="navbarNavDropdown" >
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class ="nav-link" href="accueil.php" style = "color:white;"><strong>Accueil</strong></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="ajout_sujet.php" style = "color:white;"><strong>Ajouter un sujet</strong></a>
            </li>
        </ul>
    </div>
</nav>

<?php
$sf=1;
include_once("bd.php");


if(isset($_POST['user'],$_POST['pwd'])){
    if(empty($_POST['user'])){                                  //Il faut vérifier qu'aucun des champs ne soient vides. 
        echo "Veuillez saisir un pseudo";
    }elseif(strlen($_POST['user'])>30){
        echo "Votre nom d'utilisateur est trop long";
    } elseif(empty($_POST['pwd'])){
        echo "Veuillez saisir le mot de passe";
    } 
   elseif (strlen($_POST['pwd']) < 8 ) {
        echo "Votre mot de passe doit contenir au moins 8 caractères";
    }
    else {
        if(!$bd->query("INSERT INTO users SET username='".htmlspecialchars($_POST['user'])."', password='".md5($_POST['pwd'])."'")==1){
        } else {
            echo "Vous êtes inscrit avec succès!";
            $sf=0;
        }
    }
}
if($sf=1){
    ?>
  
<br><br>
<div class="container rounded" style ="width : 30%; background-color : orange;">
<br>
    <center><h3 style = "color:white;"><strong>Inscription</strong></h3>
    <br>
    <form method="post" action="inscription.php">
        <div class="form-group">
        <center><input type="text" class="form-control" id="user" name="user" placeholder="Identifiant"></center>
        </div>
        <div class="form-group">
            <input type="password" class="form-control" id="pwd" name="pwd" placeholder="Mot de passe">
        </div>
        <br>
            <center><button type="submit" class="btn btn-primary "> S'inscrire </button></center>
    </form>
    <br>
</div>




    <?php
}
?>

</body>