<?php
// on teste si le formulaire a été soumis
if (isset ($_POST['ajout']) && $_POST['ajout']=='Ajouter') {
	if (!isset($_POST['sujet']) || !isset($_POST['titre']) || !isset($_POST['Categories'])) { //Declaration de nos variables
	$erreur = 'Les variables nécessaires au script ne sont pas définies.';
	}
	else {
	if (empty($_POST['sujet']) || empty($_POST['titre']) || empty($_POST['Categories'])) { 	// Il faut vérifier que les variables ne soient pas vides. 
		$erreur = 'Au moins un des champs est vide.';
	}

	else {
		// on inclut ce fichier qui permet la connexion à notre base de données
		include_once("bd.php");

		$categorie = $bd->prepare('INSERT INTO categories(name) VALUES(:name)');
		$categorie->execute(array('name'=>$_POST['Categories']));

		$sujet = $bd->prepare('select id from categories where name= :name');
    $sujet->execute(array('name'=>$_POST['Categories']));
    $resultat=$sujet->fetchAll();
    foreach ($resultat as $key => $value) {
    $idCategory = $value['id'];
    }

		
		$a="1";

		$sql = $bd->prepare('INSERT INTO posts(title,content,idCategory,idUser) VALUES(:title, :content, :idCategory, :idUser)');
		$sql->execute(array('title'=>$_POST['titre'],'content'=>$_POST['sujet'],'idCategory'=>$idCategory,'idUser'=>$a));
    // On lance la requête tout en vérifiant si elle est fonctionnel sinon elle renvoit un message d'erreur ! 
		$id_sujet = mysqli_insert_id();
		// on retourne vers la page d'accueil
		header('Location: accueil.php');

		exit;
	}
	}
}
?>
<html>
<meta charset="UTF-8">

<head>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/bootstrap-table.min.css">

    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>

    <script src="../js/bootstrap-table.min.js"></script>
    <script src="../js/bootstrap-table-fr-FR.min.js"></script>
    <script src="../js/bootstrap-table-export.min.js"></script>

    <title>Ajouter un sujet</title>

</head>
<body>

<nav class="navbar navbar-expand-sm "  style = "height: 5%; background-color: green;">
    <div class="collapse navbar-collapse" id="navbarNavDropdown" >
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class ="nav-link" href="accueil.php" style = "color:white;"><strong>Accueil</strong></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inscription.php" style = "color:white;"><strong>Inscription</strong></a>
            </li>
        </ul>
    </div>
</nav>
<br><br>
<center>
<h3><strong>Créer un sujet</strong></h3>
</center>

<div class="container">
  <form action="ajout_sujet.php" method="post">
  <div class="form-group">
      <label>Titre du sujet</label>
      <input type="text" class = 'form-control' id="titre" name="titre"/>
  </div>

  <div class="form-group">
    <label>Categories</label>
    <select id="Categories" class = 'form-control'name="Categories">
      <option value="Management">Management</option>
      <option value="Programmes">Programmes</option>
      <option value="Applications">Applications</option>
      <option value="RH">RH</option>
    </select>
  </div>

  <div class="form-group">
    <label>Sujet</label>
    <textarea id="sujet" name="sujet" class = 'form-control' style="height:200px"></textarea>
  </div>

    <center><button class = 'btn btn-primary' type = 'submit' name = 'ajout' value = 'Ajouter' >Ajouter</button></center>
  </form>
</div>

<?php
if (isset($erreur)){
  echo $erreur;
}
?>
</body>
