<html>
<meta charset="UTF-8">
<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/bootstrap-table.min.css">

    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>

    <script src="../js/bootstrap-table.min.js"></script>
    <script src="../js/bootstrap-table-fr-FR.min.js"></script>
    <script src="../js/bootstrap-table-export.min.js"></script>

    <title>Accueil</title>
</head>

<body>

<style>

	.bootstrap-table .fixed-table-container .fixed-table-body {
		height: unset !important;
	}

</style>

<nav class="navbar navbar-expand-sm "  style = "height: 5%; background-color: green;">
    <div class="collapse navbar-collapse" id="navbarNavDropdown" >
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class ="nav-link" href="ajout_sujet.php" style = "color:white;"><strong>Ajouter un sujet</strong></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inscription.php" style = "color:white;"><strong>Inscription</strong></a>
            </li>
        </ul>
    </div>
</nav>
<br>

<?php

// on inclut ce fichier qui permet la connexion à notre base de données
include_once("bd.php");
$sql = $bd->prepare('SELECT posts.id,title,content,username,name from posts inner join users on posts.idUser=users.id inner join categories on posts.idCategory= categories.id;');
$sql->execute();

$tab = $sql->fetchALL();
$nb_sujets = count($tab);

//On vérifie que le nombre de sujets ne soit pas nulle. 
if ($nb_sujets == 0) {
	echo '<center><h1>Aucun sujet n\'a été crée.</h1></center>';
}
else {
?>
	<div class = "container" style = "width: 75%; margin-top : 15px;">
   <center><h3><strong>Liste des sujets</strong></h3></center>

   <table style  = "text-align:center;" id="tbl-listsujet" class ="table table-striped table-hover"
        data-toggle="table" 
        data-pagination="true" 
		data-page-size="15" 
        data-page-list="[5,10,15,20,50,100,200,500,All]" 
        data-page-size="10" 
        data-page-list="[10]" 
        data-show-refresh="true"
        data-search="true" 
        data-show-export="true" 
        data-export-data-type="all" >
        <thead style = "text-align: center;">
            <tr>
                <th>Auteur</th>
                <th>Titre</th>
				<th>Catégorie</th>
				<th>Sujet</th>
            </tr>
        </thead>
        <tbody>

<?php

#Afficher les informations du sujet 
foreach ($tab as $key => $data) {
    echo '<tr><td>';
	echo htmlentities(trim($data['username']));
    echo '</td><td>';
	echo '<a href="detail_sujet.php?id_sujet_a_lire='.$data['id'].'">' , htmlentities(trim($data['title'])) , '</a></td>';
	echo '<td>';
	echo htmlentities(trim($data['name']));
	echo '</td><td>';
	echo htmlentities(trim($data['content']));
	echo '</td>';
	}
	?>
	</tbody>
</table>
<?php

}

?>


</body>
</html>