<?php

$id="root";
$pwd="";
//connexion à la base de données
try {
	$bd = new PDO('mysql:host=localhost;dbname=projet-php;port=3306',$id,$pwd) or null;
}
//Si cela ne fonctionne pas cela revoit un message d'erreur !
catch (Exception $e) {
        die('Erreur : ' . $e->getMessage().PHP_EOL);
}

?>