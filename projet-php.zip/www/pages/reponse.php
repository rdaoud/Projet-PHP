<?php
// on teste si le formulaire a été soumis
if (isset ($_POST['add']) && $_POST['add']=='Soummetre') {
	
	if (!isset($_POST['auteur']) || !isset($_POST['message']) || !isset($_GET['numero_du_sujet'])) { //Declaration de nos variables
	$erreur = 'Les variables nécessaires au script ne sont pas définies.';
	}
	else {
	if (empty($_POST['auteur']) || empty($_POST['message']) || empty($_GET['numero_du_sujet'])) { // Il faut vérifier que les variables ne sont pas vides. 
		$erreur = 'Au moins un des champs est vide.';
	}
	
	else {
		echo $_GET['numero_du_sujet'];
		// on inclut ce fichier qui permet la connexion à notre base de données
		include_once("bd.php");
		$id_post=$_GET['numero_du_sujet'];
		$user ="1";
		$sql =$bd->prepare('INSERT INTO comments(content,idPost,id) VALUES(:content, :idPost,:id)');
		$sql->execute(array('content'=>$_POST['message'],'idPost'=>$id_post,'id'=>$user));
		header('Location:detail_sujet.php?id_sujet_a_lire='.$_GET['numero_du_sujet']);
		exit;
	}
	}
}
?>

<html>
<head>
<meta charset="UTF-8">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/bootstrap-table.min.css">

    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>

    <script src="../js/bootstrap-table.min.js"></script>
    <script src="../js/bootstrap-table-fr-FR.min.js"></script>
    <script src="../js/bootstrap-table-export.min.js"></script>


</head>

<body>

<nav class="navbar navbar-expand-sm "  style = "height: 5%; background-color: green;">
    <div class="collapse navbar-collapse" id="navbarNavDropdown" >
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class ="nav-link" href="accueil.php" style = "color:white;"><strong>Accueil</strong></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="inscription.php" style = "color:white;"><strong>Inscription</strong></a>
            </li>
        </ul>
    </div>
</nav>
<br><br>
<!-- on fait pointer le formulaire vers la page traitant les données -->
<div class="container">
	<form action="reponse.php?numero_du_sujet=<?php echo $_GET['numero_du_sujet']; ?>" method="post">
		<div class="form-group">
			<label>Auteur</label>
			<input type="text" name="auteur" class = "form-control" maxlength="30" size="50" value="<?php if (isset($_POST['auteur'])) echo htmlentities(trim($_POST['auteur'])); ?>">
		</div>
		<div class="form-group">
			<div class = "row">
				<label  class = "col-form-label col-md-4" style ="display: inline-block;  width: 150px; vertical-align: top;">Réponse<label>
				<textarea class = "form-control" name="message" cols="500" rows="5"><?php if (isset($_POST['message'])) echo htmlentities(trim($_POST['message'])); ?></textarea>
			</div>
		</div>
		<center><button class = 'btn btn-primary' type = 'submit' name = 'add' value = 'Soummetre' >Soummetre</button></center>
	</form>

<?php
if (isset($erreur)){
	echo $erreur;
} 
?>
</div>
</body>
</html>